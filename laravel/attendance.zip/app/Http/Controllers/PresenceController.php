<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;
use App\service;
use App\daily;
use App\jabatan;
use App\users;
use App\activity;
use DB;
use PDF;
use App\Helper\record;
use Redirect;
use Image;
use Mail;
use App\Mail\ForgotPassword;
use App\Mail\SecurityAlert;
class PresenceController extends Controller
{

    public function pesan(){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','Please, login first');
        }else{
        $nip = Session::get('nip');
        $hakakses = Session::get('hakakses');
        $service=DB::table('service')->where('status','');
        $service=$service->get();

        return view('admin.isi_pesan',[
            'service'=>$service,
            'hakakses'=>$hakakses,
            'navhome'=>'',
            'navpresence'=>'',
            'navactivity'=>'',
            'navemployee'=>'']);
        }
    }
	public function Index(){
		if (Session::has('login')) {
			return redirect('/admin');
		}else{
			return view('index');
		}
	}

    public function loginPost(Request $request){
        $username = $request->nip;
        $password = md5($request->password);
        $data = DB::table('users')->where('email',$username);
        $cdata=$data->count();
        $data=$data->first();


    if ($cdata>=1) {
        if($data->email==$username){ //apakah email tersebut ada atau tidak
            //if(hash::check($password,$data->password)){  ---bycript---
               if ($data->password==$password) {
                Session::put('nip',$data->nip);
                Session::put('email',$data->email);
                Session::put('nama',$data->nama);
                Session::put('hakakses',$data->hakakses);
                Session::put('kd',$data->kd);
                Session::put('login',TRUE);
                return redirect('admin');
            }
            else{
                return redirect('/')->with('alert','Try again, your email or password are wrong!');
            }
        }
        else{
            return redirect('/')->with('alert','Try again, your email or password are wrong!');
        }
    }else{
    return redirect('/')->with('alert','Try again, your email or password are wrong!');
}
}

    //masih harus diganti yang bawah

    public function BerhasilLogin(){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','Please, login first');
        }else{
            $nip = Session::get('nip');
            $hakakses = Session::get('hakakses');
            $jmlusers=users::count();
            $genderL=users::where('gender','Laki-laki')->count();
            $genderP=users::where('gender','Perempuan')->count();
            $jmlO=users::where('kd','O001')->count();
            $jmlS=users::where('kd','S001')->count();
            $jmlT=users::where('kd','T001')->count();

            $operasional=($jmlO/$jmlusers)*100;
            $sales=($jmlS/$jmlusers)*100;
            $technical=($jmlT/$jmlusers)*100;

            if ($hakakses=='admin' OR $hakakses=='super user') {
                $table=record::Daily()->count();
                $Atable=record::Activity()->count();
            }else{
                
                $table=record::Daily()->where('daily.nip',$nip)->count();
                $Atable=record::Activity()->where('activity.nip',$nip)->count();

            }

            $qD=DB::table('daily')->where('nip',$nip)->orderBy('id','desc')->limit('1');
            $qA=DB::table('activity')->where('nip',$nip)->orderBy('id','desc')->limit('1');

            $maxD=$qD->first();
            $maxA=$qA->first();
            //validasi daily
            if ($qD->count()==0 OR $maxD->outtime !="00:00:00") {
                $tmbl = '';
            }elseif($maxD->outtime =="00:00:00"){
                $tmbl = 'disabled';
            }
            //validasi activity
            if ($qA->count()==0 OR $maxA->outtime !="00:00:00") {
                $tmbll = '';
            }elseif ($maxA->outtime =="00:00:00"){
                $tmbll = 'disabled';
            }

            $cust=DB::table('customer')->orderBY('namapt','asc')->get();

            include 'pesan.php';

                return view("admin.grafik",[
                    'tmbl'=>$tmbl,
                    'tmbll'=>$tmbll,
                    'cust'=>$cust,
                    'status'=>$status,
                    'hakakses'=>$hakakses,
                    'operasional'=>$operasional,
                    'sales'=>$sales,
                    'technical'=>$technical,
                    'jmlO'=>$jmlO,
                    'jmlS'=>$jmlS,
                    'jmlT'=>$jmlT,
                    'genderL'=>$genderL,
                    'genderP'=>$genderP,
                    'table'=>$table,
                    'Atable'=>$Atable,
                    'jmlusers'=>$jmlusers]);

        }
    }

    public function HomeA(){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','Please, login first');
        }else{
            $nip = Session::get('nip');
            $hakakses = Session::get('hakakses');
            //$isi = DB::table('users')->join('jabatan','users.kd','=','jabatan.kd')->where('users.nip',$nip)->first();
            $tgls = date('Y-m-d');
            $table = record::Daily();
			$Atable=record::Activity();

            include 'pesan.php';

            if ($hakakses=='admin' OR $hakakses=='super user') {
                $jmltable=$table->count();
                $table=$table->get();
								$jmlAtable=$Atable->count();
                $Atable=$Atable->get();
            }else{
                $jmltable=$table->where('daily.nip',$nip)->count();
                $table=$table->where('daily.nip',$nip)->get();
								$jmlAtable=$Atable->where('activity.nip',$nip)->count();
                $Atable=$Atable->where('activity.nip',$nip)->get();

            }

                return view("admin.homeA",[
                    'table'=>$table,
                    'jmltable'=>$jmltable,
					'Atable'=>$Atable,
                    'status'=>$status,
                    'jmlAtable'=>$jmlAtable,
                    'hakakses'=>$hakakses,
                    'navhome'=>'btn-light btn',
                    'navpresence'=>'',
                    'navactivity'=>'',
                    'navemployee'=>'']);
            }

        }

    public function Logout(){
        Session::flush();
        return redirect("/")->with('alert','Logout Success');
    }

    public function Record(){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','Please, Login First');
        }else{
        $nip = Session::get('nip');
        $hakakses = Session::get('hakakses');
        $date1=date('Y-m').'-01';
        $date2=date('Y-m').'-31';
        include "bulan.php";
        $isitbl=record::RecordDaily($date1,$date2);

        if ($hakakses=='admin' OR $hakakses=='super user') {
                $tbl=$isitbl->count();
                $isitbl=$isitbl->orderBY('daily.date','desc')->get();
            }else{
                $tbl=$isitbl->where('users.nip',$nip)->count();
                $isitbl=$isitbl->where('users.nip',$nip)->orderBY('daily.date','desc')->get();
            }
        include 'pesan.php';

        return view('admin.recordpresence',[
            'date1'=>$date1,
            'date2'=>$date2,
            //'bulan'=>$bulan,
            'ANbulan'=>$ANbulan,
            'Abulan'=>$Abulan,
            'bbulan'=>$bbulan,
            'isitbl'=>$isitbl,
            'status'=>$status,
            'tbl'=>$tbl,
            'hakakses'=>$hakakses,
            'navhome'=>'',
            'navpresence'=>'btn-light btn',
            'navactivity'=>'',
            'navemployee'=>'']);
        }
    }

    public function Export($date1,$date2,$ex){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','Please, Login First');
        }else{
        include "bulan.php";
        $isitbl=record::RecordDaily($date1,$date2)->orderBY('daily.date','asc')->get();
         $sum=DB::table('daily')->select('users.nama','daily.nip',DB::raw('count(*)as total'))->join('users','daily.nip','=','users.nip')->whereBetween('daily.date',[$date1,$date2])->groupBy('daily.nip','users.nama')->get();

          if ($ex=='excel') {
           $export="<script type='text/javascript'>exportTabelKeCSV('Record_Attendance_".$date1."_".$date2.".csv')</script>";
           $exportN=header('Refresh: 0; URL='.url('/record').''); 
        }elseif ($ex=='pdf') {
            $export="<script>window.print()</script>";
            $exportN=header('Refresh: 0; URL='.url('/record').'');
        }

        return view('admin.report_record',[
            'export'=>$export,
            'exportN'=>$exportN,
            'date1'=>$date1,
            'date2'=>$date2,
            'ANbulan'=>$ANbulan,
            'Abulan'=>$Abulan,
            'bbulan'=>$bbulan,
            'isitbl'=>$isitbl,
            'sum'=>$sum]);
        }
    }

    public function ViewActivity(){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','login terlebih dahulu');
        }else{
        $nip = Session::get('nip');
        $hakakses = Session::get('hakakses');
        $date1=date('Y-m').'-01';
        $date2=date('Y-m').'-31';
        include "bulan.php";
        $isitbl=record::RecordActivity($date1,$date2);

        if ($hakakses=='admin' OR $hakakses=='super user') {
                $tbl=$isitbl->count();
                $isitbl=$isitbl->orderBY('activity.date','desc')->get();
            }else{
                $tbl=$isitbl->where('users.nip',$nip)->count();
                $isitbl=$isitbl->where('users.nip',$nip)->orderBY('activity.date','desc')->get();
            }

            include 'pesan.php';


        return view('admin.record_activity',[
            'date1'=>$date1,
            'date2'=>$date2,
            //'bulan'=>$bulan,
            'ANbulan'=>$ANbulan,
            'Abulan'=>$Abulan,
            'bbulan'=>$bbulan,
            'isitbl'=>$isitbl,
            'status'=>$status,
            'tbl'=>$tbl,
            'hakakses'=>$hakakses,
            'navhome'=>'',
            'navpresence'=>'',
            'navactivity'=>'btn-light btn',
            'navemployee'=>'']);
        }
    }




    public function ViewAdd(){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','login terlebih dahulu');
        }else{
            $nip = Session::get('nip');
            $hakakses = Session::get('hakakses');
            $jabatan=jabatan::all();

             if ($hakakses=='admin') {
                $rules='';
            }else{
                $rules='disabled';
            }
            include 'pesan.php';

            return view('admin.add_employee',[
            'jabatan'=>$jabatan,
            'rules'=>$rules,
            'hakakses'=>$hakakses,
            'status'=>$status,
            'navhome'=>'',
            'navpresence'=>'',
            'navactivity'=>'',
            'navemployee'=>'btn-light btn']);
        }
    }

    public function ViewRecord(Request $req){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','login terlebih dahulu');
        }else{
        $nip = Session::get('nip');
        $hakakses = Session::get('hakakses');
        $date1 =$req->date1;
        $date2 =$req->date2;
        $tahun=date('Y');
        $bulan=date('m');
        include "bulan.php";
         include 'pesan.php';
        $isitbl=record::RecordDaily($date1,$date2);

        if ($hakakses=='admin' OR $hakakses=='super user') {
                $tbl=$isitbl->count();
                $isitbl=$isitbl->orderBy('daily.date','desc')->get();
            }else{
                 $tbl=$isitbl->where('users.nip',$nip)->count();
                $isitbl=$isitbl->where('users.nip',$nip)->orderBy('daily.date','desc')->get();
            }
        return view('admin.recordpresence',[
            'date1'=>$date1,
            'date2'=>$date2,
            'tahun'=>$tahun,
            'bulan'=>$bulan,
            'ANbulan'=>$ANbulan,
            'Abulan'=>$Abulan,
            'bbulan'=>$bbulan,
            'isitbl'=>$isitbl,
            'tbl'=>$tbl,
            'status'=>$status,
            'hakakses'=>$hakakses,
            'navhome'=>'',
            'navpresence'=>'btn-light btn',
            'navactivity'=>'',
            'navemployee'=>'']);
        }
    }

    public function AddNew(Request $req){
			if (!Session::get('login')) {
					return redirect('/')->with('alert','login terlebih dahulu');
			}else{
			$nip = Session::get('nip');
			$hakakses = Session::get('hakakses');
        $nip=$req->nip;
        $nama=$req->nama;
        $gender=$req->gender;
        $email=$req->email;
        $jabatan=$req->jabatan;
        $password=md5($req->password);
        $password2=md5($req->password2);
        $hakakses='karyawan';

        if ($password==$password2) {
            $save=['nip'=>$nip,'nama'=>$nama,'gender'=>$gender,'email'=>$email,'kd'=>$jabatan,'password'=>$password,'hakakses'=>$hakakses,'pict'=>''];

        users::insert($save);
        return redirect('/addemployee')->with('success_alert','! Success Add New Data');
        }else{
            return redirect('/addemployee')->with('alert','! Password Not Same Repeat Again');
        }
			}
    }

    public function ViewEmp(){
    if (!Session::get('login')) {
            return redirect('/')->with('alert','login terlebih dahulu');
        }else{
        $nip = Session::get('nip');
        $hakakses = Session::get('hakakses');
        $isi=users::join('jabatan','users.kd','=','jabatan.kd')->get();

        include 'pesan.php';
        return view('admin.data_employee',[
            'isi'=>$isi,
            'status'=>$status,
            'hakakses'=>$hakakses,
            'navhome'=>'',
            'navpresence'=>'',
            'navactivity'=>'',
            'navemployee'=>'btn-light btn']);
    }
}

public function DeleteData($nip){

        users::where('nip',$nip)->delete();

        return redirect('/viewemployee')->with('success_alert','! Data Has Been Deleted');
    }


    public function ViewEdit($id){
        $view=users::join('jabatan','users.kd','=','jabatan.kd')->where('nip',$id)->first();
        $jabatan=jabatan::all();
        $hakakses = Session::get('hakakses');
        return view('admin.edit_karyawan',[
            'view'=>$view,
            'jabatan'=>$jabatan,
            'hakakses'=>$hakakses,
            'navhome'=>'',
            'navpresence'=>'',
            'navactivity'=>'',
            'navemployee'=>'btn-light btn']);
    }

    public function SaveEdit(Request $req){
        $nip=$req->nip;
        $nama=$req->nama;
        $gender=$req->gender;
        $email=$req->email;
        $jabatan=$req->jabatan;
        $password=md5($req->password);
        $password2=md5($req->password2);

        if ($password=='') {
            $save=['nip'=>$nip,
            'nama'=>$nama,
            'gender'=>$gender,
            'email'=>$email,
            'kd'=>$jabatan];

            users::where('nip',$nip)->update($save);
            return redirect('/viewemployee');
        }elseif ($password==$password2) {
            $save=['nip'=>$nip,
            'gender'=>$gender,
            'nama'=>$nama,
            'email'=>$email,
            'kd'=>$jabatan,
            'password'=>$password];

            users::where('nip',$nip)->update($save);
            return redirect('/viewemployee');
        }elseif ($password!=$password2) {
            return redirect('/edit/'.$nip.'')->with('alert','Password Not Same !');
        }
    }


    public function SearchActivity(Request $req){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','login terlebih dahulu');
        }else{
        $nip = Session::get('nip');
        $hakakses = Session::get('hakakses');
        $date1 =$req->date1;
        $date2 =$req->date2;
        $tahun=date('Y');
        $bulan=date('m');
        include "bulan.php";
        include "pesan.php";
        $isitbl=record::RecordActivity($date1,$date2);
        if ($hakakses=='admin' OR $hakakses=='super user') {
                $tbl=$isitbl->count();
                $isitbl=$isitbl->orderBy('activity.date','desc')->get();
            }else{
                $tbl=$isitbl->where('users.nip',$nip)->count();
                $isitbl=$isitbl->where('users.nip',$nip)->orderBy('activity.date','desc')->get();
            }

        return view('admin.record_activity',[
            'date1'=>$date1,
            'date2'=>$date2,
            'tahun'=>$tahun,
            'bulan'=>$bulan,
            'ANbulan'=>$ANbulan,
            'Abulan'=>$Abulan,
            'bbulan'=>$bbulan,
            'isitbl'=>$isitbl,
            'tbl'=>$tbl,
            'status'=>$status,
            'hakakses'=>$hakakses,
            'navhome'=>'',
            'navpresence'=>'',
            'navactivity'=>'btn-light btn',
            'navemployee'=>'']);
        }
    }

    public function ExportActivity($date1,$date2,$ex){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','login terlebih dahulu');
        }else{
        include "bulan.php";
        $isitbl=record::RecordActivity($date1,$date2)->orderBy('activity.date','asc')->get();

        if ($ex=='excel') {
           $export="<script type='text/javascript'>exportTabelKeCSV('Record_Activity_".$date1."_".$date2.".csv')</script>";
           $exportN=header('Refresh: 0; URL='.url('/recordactivity').'');
        }elseif ($ex=='pdf') {
            $export="<script>window.print()</script>";
            $exportN=header('Refresh: 0; URL='.url('/recordactivity').'');
        }
            

        $sum=DB::table('activity')->select('users.nama','activity.nip',DB::raw('count(*)as total'))->join('users','activity.nip','=','users.nip')->whereBetween('activity.date',[$date1,$date2])->groupBy('activity.nip','users.nama')->get();
        return view('admin.report_activity',[
            'export'=>$export,
            'exportN'=>$exportN,
            'date1'=>$date1,
            'date2'=>$date2,
            'ANbulan'=>$ANbulan,
            'Abulan'=>$Abulan,
            'bbulan'=>$bbulan,
            'isitbl'=>$isitbl,
            'sum'=>$sum]);
        }
    }

    public function helped (){
        if (!Session::get('login')) {
            return redirect('/')->with('alert','login terlebih dahulu');
        }else{
        $isiP=service::where('status','')->get();
        include 'pesan.php';
        return view('admin.isi_pesan',['isiP'=>$isiP,'status'=>$status]);
    }
    }

    public function Mark($status,$id){
        $simpan=['status'=>$status];
        DB::table('service')->where('id',$id)->update($simpan);
        return redirect ('/helpdesks');

    }

    public function forgotpassword(request $req){
        $email = $req->email;
        $sub = $req->Subject;
        $dbusers=DB::table('users')->where('email',$email);
        $count=$dbusers->count();
        $cariemail=$dbusers->first();
       

        if ($count==0) {
            return redirect ('/')->with('alert',"Your Email ".$email." Can't Be Found");
        }elseif ($cariemail->email==$email) {
            $nm=$cariemail->nama;
            Mail::to($email)->send(new SecurityAlert($nm,$email,$sub));
            return redirect ('/')->with('alert',"Your Message Has Been Sent, Check Your Email");
        }
        
    }

    public function resetpassword($nm,$email,$sub){

            $save=['email'=>$email,'subject'=>$sub,'status'=>'','description'=>''];

            $simpan=DB::table('service')->insert($save);
            $newpass= str_random(8);
            $spass=md5($newpass);
            DB::table('users')->update(['password'=>$spass]);
            Mail::to($email)->send(new ForgotPassword($nm,$email,$newpass));
            return redirect ('/')->with('alert',"Your Message Has Been Sent, Check Your Email For New Password");
    }

    public function web(){
        return Redirect::to('http://www.ib-synergy.co.id');
    }

    public function CIn(Request $req){
        $nip = Session::get('nip');
        $hakakses = Session::get('hakakses');
        $now = \Carbon\Carbon::now('Asia/Jakarta');
        $date=$now->format('Y-m-d');
        $intime = $now->format('H:i:s');
        $loc=$req->loc;

        if (isset($req->checkin)) {
            if ($loc=='') {
                return redirect('/admin')->with('alert','Your Location Is Not Recognize !!!');
            }else{
            $save=['nip'=>$nip,'date'=>$date,'intime'=>$intime,'locin'=>$loc,'outtime'=>'00:00:00','locout'=>'','note'=>''];

            DB::table('daily')->insert($save);
            return redirect('/admin')->with('successalert','Success Check In');
            }
        }elseif (isset($req->checkout)) {
            if ($loc=='') {
                return redirect('/admin')->with('alert','Your Location Is Not Recognize !!!');
            }else{
            $edit=['outtime'=>$intime,'locout'=>$loc];
            $max=DB::table('daily')->select(DB::raw('max(id) as max'))->where('nip',$nip)->first();
            DB::table('daily')->where('id',$max->max)->update($edit);
            return redirect('/admin')->with('successalert','Success Check Out');
        }
        }

    }

    public function AIn(Request $req){
        $nip = Session::get('nip');
        $hakakses = Session::get('hakakses');
        $now = \Carbon\Carbon::now('Asia/Jakarta');
        $date=$now->format('Y-m-d');
        $intime = $now->format('H:i:s');
        $loc=$req->loc;
        $desc=$req->description;
        $cust=$req->customer;
        //FOTO
        


        if (isset($req->activityin)) {
            if ($loc=='') {
                return redirect('/admin')->with('alert','Your Location Is Not Recognize !!!');
            }else{
    
            $img=$req->file('image');
            $Nimg=$img->getClientOriginalName();
            $img->move(public_path().'../../android/attrack/image',$Nimg);

            $save=['nip'=>$nip,'date'=>$date,'intime'=>$intime,'locin'=>$loc,'outtime'=>'00:00:00','locout'=>'','subject'=>$desc,'description'=>'','pic'=>$Nimg,'customer'=>$cust];

            DB::table('activity')->insert($save);
            return redirect('/admin')->with('successalert','Success Check In');
                }
        }elseif (isset($req->activityout)) {
            if ($loc=='') {
                return redirect('/admin')->with('alert','Your Location Is Not Recognize !!!');
            }else{
            $edit=['outtime'=>$intime,'locout'=>$loc,'description'=>$desc];
            $max=DB::table('activity')->select(DB::raw('max(id) as max'))->where('nip',$nip)->first();
            DB::table('activity')->where('id',$max->max)->update($edit);
            return redirect('/admin')->with('successalert','Success Check Out');
        }
        }

    }
        

}

 /*public function AIn(Request $req){
        $nip = Session::get('nip');
        $hakakses = Session::get('hakakses');
        $now = \Carbon\Carbon::now('Asia/Jakarta');
        $date=$now->format('Y-m-d');
        $intime = $now->format('H:i:s');
        $loc=$req->loc;
        $desc=$req->description;
        $cust=$req->customer;
        //FOTO
        


        if (isset($req->activityin)) {
            if ($loc=='') {
                return redirect('/admin')->with('alert','Your Location Is Not Recognize !!!');
            }else{
    
            $img=$req->file('image');
            $Naimg=$img->getClientOriginalName();
            $img->move('../android/attrack/image',$Naimg);
            $Nimg='https://www.ib-synergy.co.id/android/attrack/image/'.$Naimg;

            $save=['nip'=>$nip,'date'=>$date,'intime'=>$intime,'locin'=>$loc,'outtime'=>'00:00:00','locout'=>'','subject'=>$desc,'description'=>'','image'=>$Nimg,'customer'=>$cust];

            DB::table('activity')->insert($save);
            return redirect('/admin')->with('successalert','Success Check In');
                }
        }elseif (isset($req->activityout)) {
            if ($loc=='') {
                return redirect('/admin')->with('alert','Your Location Is Not Recognize !!!');
            }else{
            $edit=['outtime'=>$intime,'locout'=>$loc,'description'=>$desc];
            $max=DB::table('activity')->select(DB::raw('max(id) as max'))->where('nip',$nip)->first();
            DB::table('activity')->where('id',$max->max)->update($edit);
            return redirect('/admin')->with('successalert','Success Check Out');
        }
        }

    }
