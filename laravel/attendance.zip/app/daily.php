<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class daily extends Model
{
     protected $table = "daily";

    public $timestamps = false;
}
