Hello {{$nm}}.<br><br><br>

Your account password has been reset by Administrator.<br><br>

This your new password : {{$newpass}}<br><br>
For your account {{$email}} change your password immedietly via app, if any problem click link below to chat with Administrator.<br>
<a href="https://tawk.to/chat/5be7c3b50e6b3311cb78bf51/default">https://tawk.to/chat/5be7c3b50e6b3311cb78bf51/default</a><br><br><br>

Thank You Have a Nice Day.
