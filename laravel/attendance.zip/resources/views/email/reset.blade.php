Hello {{$nm}}.<br><br><br>

Our system detected you want change password.<br><br>

If not you ignore this email !!!!<br>
If it is you click link below, and check your email for new password.<br><br><br>

<a href="https://192.168.1.86/attendance/public/reset/{{$nm}}/{{$email}}/{{$sub}}">Change Password</a><br><br><br>
Keep Your Email Save, Thank You Have a Nice Day.
