<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//ADMIN
Route::get('/','PresenceController@Index');//balik ke home
Route::post('/login','PresenceController@LoginPost');//validasi login
Route::get('/admin','PresenceController@BerhasilLogin');//hasil login
Route::get('/logout','PresenceController@Logout');//logout
Route::get('/homeA','PresenceController@HomeA');//
Route::get('/record','PresenceController@Record');//tampilan home admin
Route::get('/export/{date1}/{date2}/{ex}','PresenceController@Export');//export record presence
Route::get('/recordactivity','PresenceController@ViewActivity');//melihat rocord activity
Route::get('/addemployee','PresenceController@ViewAdd');//tampil tambah data
Route::post('/addnew','PresenceController@AddNew');//tambah data karyawan baru
Route::get('/viewemployee','PresenceController@ViewEmp');//menampilkan data karyawan
Route::get('/deletedata/{nip}','PresenceController@DeleteData');//delete data karyawan
Route::post('/searchactivity','PresenceController@SearchActivity');//search di activity
Route::post('/search','PresenceController@ViewRecord');//hasil filter record_presence
Route::get('/exportactivity/{date1}/{date2}/{ex}','PresenceController@ExportActivity');//export activity
Route::get('/edit/{id}','PresenceController@ViewEdit');//tampil form edit
Route::post('/saveedit','PresenceController@SaveEdit');//save edit
Route::get('/helpdesks','PresenceController@pesan');//menuju isi pesan helpdesk
Route::get('/mark/{status}/{id}','PresenceController@Mark');//tanda pesan sudah dibaca

//reset password
Route::post('/forgot','PresenceController@forgotpassword');
Route::get('/reset/{nm}/{email}/{sub}','PresenceController@resetpassword');


//REDIRECT KE IBS
Route::get('/web','PresenceController@web');
//KARYAWAN
Route::post('/checkin','PresenceController@CIn');
Route::post('/activityin','PresenceController@AIn');




