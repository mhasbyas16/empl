<?php

$con=mysqli_connect("localhost","root","","absensi");

if (mysqli_connect_errno()) {
	printf("Gagal melakukan koneksi");
}

?>